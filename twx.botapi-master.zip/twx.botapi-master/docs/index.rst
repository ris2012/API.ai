.. twx.botapi documentation master file, created by
   sphinx-quickstart on Sat Jun 27 15:07:02 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

twx.botapi: Unofficial Telegram Bot API Client
==============================================

Contents:

.. toctree::
   :maxdepth: 3

   twx/botapi/botapi.rst




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

